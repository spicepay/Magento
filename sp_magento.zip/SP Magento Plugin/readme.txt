1. Unpack spicepay-magento1.9.zip
2. Copy the 'app' folder to the root of your Magento installation.
3. Open Magento Admin and navigate to System > Configuration > Payment Methods
4. Scroll down to 'Spicepay Bitcoin Payment Gateway' and follow the instructions. If you can't find 'Spicepay Bitcoin Payment Gateway', try clearing your Magento cache.